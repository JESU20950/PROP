package Domain.Player;


import Domain.Game;
import Domain.Table;

public class Machine2 extends Player{
    public Machine2() {
        super.name = "Machine2";
    }

    public void move_piece(Game g) {

    }

    public boolean isMachine() {
        return true;
    }

    public void move_piece(Table t) {

    }

}
